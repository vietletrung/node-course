const express = require('express')
const app = express()

const mongoose = require('./db/mongodb.js')
const User = require('./models/users.js')
const Task = require('./models/tasks.js')
const userRouter = require('./routes/users.js')
const { ObjectId } = require('mongodb')

const port = process.env.PORT | 3000

app.use(express.json())
app.use(userRouter)

app.post('/tasks', async(req, res) => {
    console.log(req.body)
    const task = new Task(req.body)

    try {
        await task.save()
        res.status(201).send(task)
    }catch (e) {
        res.send(e)
    }
})

app.listen(port, () => {
    console.log('listen on port ' + port)
})
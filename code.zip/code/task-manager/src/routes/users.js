const express = require('express')
const User = require('../models/users.js')
const auth = require('../middleware/auth.js')
//const app = new express()

const router = new express.Router()

router.post('/users', (req, res) => {
    //res.send({text: 'response'})
    console.log('req body:' +req.body)
    const user = new User(req.body)
    console.log(user)
    user.save().then(() => {
        res.status(201).send(user)
    }).catch((error) => {
        res.send(error)
    })
})


router.get('/users',auth, async(req,res) => {
    try {
        const users = await User.find({})
        res.send(users)
    }
    catch (e) {
        res.status(500).send(e)
    }
})

router.get('/user/:id',auth, async(req,res) => {
    const _id = req.params.id
    try {
        const user = await User.findById(_id)
        if (!user)
        {
            res.status(404).send('user not found')
        }
        res.send(user)
    }catch (e){
        res.status(500).send('application error')
    }
})

router.post('/users/login', async (req,res) => {
    console.log('call login')
    try {
        const user = await User.findByCredentials(req.body.email, req.body.password)
        console.log(user)

        const token = await user.generateAuthToken()
        console.log(user)
        res.status(200).send({user, token})
    }catch (e) {
        res.send('login failed')
    }
})

router.post('/users/logout', auth, async(req,res) => {
    console.log('call logout' + req.user.tokens)
    try {
        req.user.tokens = req.user.tokens.filter((token) =>{
            return req.user.tokens != req.token
        })

        await req.user.save()
        res.send()
    }catch (e) {
        res.send('logout failed')
    }
})

router.post('/users/logoutAll', auth, async(req,res) => {
    console.log('call logout' + req.user.tokens)
    try {
        req.user.tokens = []

        await req.user.save()
        res.send()
    }catch (e) {
        res.send('logout failed')
    }
})

router.get('/users/me', auth, async(req,res) => {
    res.send(req.user)
})

router.patch('/users',auth, async(req,res) => {
    // const _id = req.params.id
    const updates = Object.keys(req.body)
    const allowUpdates = ['age', 'name']

    const isValidOperation = updates.every((update) => allowUpdates.includes(updates))
    if(!isValidOperation) {
        return res.status(400).send('invalid update')
    }

    try {
        const user = await User.findByIdAndUpdate(req.user._id, req.body, {new:true, runValidators: true})
        if(!user) {
            res.status(404).send('can not find the user')
        }

        return res.status(200).send(user)
    }catch(e) {
        return res.status(500).send('application error')
    }
})

router.delete('/users/me', auth, async(req,res) => {
    // const _id = req.params.id
    try {
        // const user = await User.findByIdAndDelete(req.user._id)
        // if(!user){
        //     res.status(404).send()
        // }
        await req.user.remove()

    }catch (e) {
        res.status(500).send()
    }
})

module.exports = router
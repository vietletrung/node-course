console.log('utils.js')

const name = "viet"

const add = function(a,b) {
    return a + b    
}

module.exports = add